import { useForm } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';
import { useState, useEffect } from 'react';

export default function Edit({ transaction, customers, services, auth }) {
    const { data, setData, put, errors, processing } = useForm({
        invoice_number: transaction.invoice_number || '',
        customer_id: transaction.customer_id || '',
        transaction_date: transaction.transaction_date ? transaction.transaction_date.substr(0, 10) : '',
        items: transaction.details.map(d => ({
            service_id: d.service_id,
            quantity: d.quantity,
            is_express: d.is_express,
            notes: d.notes || ''
        })),
        discount_type: transaction.discount_type || 'amount',
        discount_value: transaction.discount_value || 0,
        paid_amount: transaction.paid_amount || 0,
        payment_status: transaction.payment_status || 'belum lunas',
        notes: transaction.notes || '',
        estimated_completion: transaction.estimated_completion ? transaction.estimated_completion.substr(0, 10) : '',
        status: transaction.status || 'pending',
    });

    // Searchable Select States - HANYA UNTUK CUSTOMER
    const [customerSearch, setCustomerSearch] = useState('');
    const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
    const [filteredCustomers, setFilteredCustomers] = useState([]);

    // Initialize customer search
    useEffect(() => {
        // Set initial customer name
        const customer = customers?.find(c => c.id == data.customer_id);
        if (customer) {
            setCustomerSearch(customer.name || '');
        }

        // Initialize filtered customers
        if (customers && Array.isArray(customers)) {
            setFilteredCustomers(customers);
        }
    }, []);

    // Handle customer search
    const handleCustomerSearch = (searchTerm) => {
        setCustomerSearch(searchTerm);
        
        if (!customers || !Array.isArray(customers)) {
            setFilteredCustomers([]);
            setShowCustomerDropdown(false);
            return;
        }

        if (!searchTerm.trim()) {
            setFilteredCustomers(customers);
            setShowCustomerDropdown(true);
            return;
        }

        const searchLower = searchTerm.toLowerCase();
        const filtered = customers.filter(customer => {
            const name = customer.name || '';
            const phone = customer.phone_number || '';
            
            return name.toLowerCase().includes(searchLower) || 
                   phone.toLowerCase().includes(searchLower);
        });
        
        setFilteredCustomers(filtered);
        setShowCustomerDropdown(true);
    };

    const selectCustomer = (customer) => {
        setData('customer_id', customer.id);
        setCustomerSearch(customer.name || '');
        setShowCustomerDropdown(false);
    };

    const clearCustomerSelection = () => {
        setData('customer_id', '');
        setCustomerSearch('');
        setShowCustomerDropdown(false);
        setFilteredCustomers(customers || []);
    };

    // Hitung total sebelum diskon
    const calculateTotal = () => {
        return data.items.reduce((sum, item) => {
            const service = services.find(s => s.id == item.service_id);
            const price = service ? parseFloat(service.price) : 0;
            return sum + (price * item.quantity);
        }, 0);
    };

    // Hitung final total setelah diskon
    const calculateFinalTotal = () => {
        const total = calculateTotal();
        if (data.discount_type === 'amount') {
            return Math.max(total - parseFloat(data.discount_value || 0), 0);
        } else if (data.discount_type === 'percent') {
            return Math.max(total - (total * parseFloat(data.discount_value || 0) / 100), 0);
        }
        return total;
    };

    const handleItemChange = (idx, field, value) => {
        const items = [...data.items];
        
        // Handle quantity sebagai float
        if (field === 'quantity') {
            items[idx][field] = parseFloat(value) || 0;
        } else {
            items[idx][field] = value;
        }
        
        setData('items', items);
    };

    const addItem = () => {
        setData('items', [...data.items, { service_id: '', quantity: 1, is_express: false, notes: '' }]);
    };

    const removeItem = (idx) => {
        const items = data.items.filter((_, i) => i !== idx);
        setData('items', items);
    };

    const handleDiscountTypeChange = (e) => {
        setData('discount_type', e.target.value);
    };

    const handleDiscountValueChange = (e) => {
        setData('discount_value', e.target.value);
    };

    const handlePaymentStatusChange = (e) => {
        setData('payment_status', e.target.value);
    };

    const submit = (e) => {
        e.preventDefault();
        setData('total_amount', calculateTotal());
        setData('final_total', calculateFinalTotal());
        put(route('transactions.update', transaction.id));
    };

    return (
        <AuthenticatedLayout user={auth.user} header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Edit Transaction #{transaction.invoice_number}</h2>}>
            <Head title="Edit Transaction" />
            <form onSubmit={submit} className="space-y-4 p-6 bg-white rounded shadow max-w-3xl mx-auto mt-8">
                
                {/* INVOICE NUMBER (READ ONLY) */}
                <div>
                    <label className="block font-medium">Invoice Number</label>
                    <input 
                        type="text" 
                        value={data.invoice_number} 
                        disabled 
                        className="w-full border rounded px-2 py-1 bg-gray-100" 
                    />
                </div>

                {/* CUSTOMER SELECT - SEARCHABLE */}
                <div>
                    <label className="block font-medium">Customer *</label>
                    <div className="relative">
                        <input
                            type="text"
                            value={customerSearch}
                            onChange={(e) => handleCustomerSearch(e.target.value)}
                            onFocus={() => setShowCustomerDropdown(true)}
                            className="w-full border rounded px-2 py-1 pr-8"
                            placeholder="Ketik nama atau nomor telepon..."
                            autoComplete="off"
                        />
                        
                        {/* Clear button */}
                        {customerSearch && (
                            <button
                                type="button"
                                onClick={clearCustomerSelection}
                                className="absolute right-2 top-2 text-gray-400 hover:text-gray-600"
                            >
                                ✕
                            </button>
                        )}

                        {/* Dropdown Results */}
                        {showCustomerDropdown && (
                            <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded shadow-lg max-h-60 overflow-y-auto">
                                {filteredCustomers && filteredCustomers.length > 0 ? (
                                    filteredCustomers.map((customer) => (
                                        <div
                                            key={customer.id}
                                            onClick={() => selectCustomer(customer)}
                                            className="px-3 py-2 hover:bg-blue-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                                        >
                                            <div className="font-medium">{customer.name}</div>
                                            <div className="text-sm text-gray-600">📞 {customer.phone_number}</div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="px-3 py-2 text-center text-gray-500">
                                        Pelanggan tidak ditemukan
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                    {errors.customer_id && <div className="text-red-500 text-sm">{errors.customer_id}</div>}
                </div>

                {/* TRANSACTION DATE */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block font-medium">Tanggal Transaksi *</label>
                        <input 
                            type="date" 
                            value={data.transaction_date} 
                            onChange={e => setData('transaction_date', e.target.value)} 
                            className="w-full border rounded px-2 py-1"
                            required
                        />
                        {errors.transaction_date && <div className="text-red-500 text-sm">{errors.transaction_date}</div>}
                    </div>

                    <div>
                        <label className="block font-medium">Estimasi Selesai *</label>
                        <input 
                            type="date" 
                            value={data.estimated_completion} 
                            onChange={e => setData('estimated_completion', e.target.value)} 
                            className="w-full border rounded px-2 py-1"
                            required
                        />
                        {errors.estimated_completion && <div className="text-red-500 text-sm">{errors.estimated_completion}</div>}
                    </div>
                </div>

                {/* STATUS */}
                <div>
                    <label className="block font-medium">Status Transaksi</label>
                    <select value={data.status} onChange={e => setData('status', e.target.value)} className="w-full border rounded px-2 py-1">
                        <option value="pending">🟡 Pending</option>
                        <option value="processing">🔵 Processing</option>
                        <option value="completed">🟢 Completed</option>
                        <option value="delivered">📦 Delivered</option>
                        <option value="cancelled">🔴 Cancelled</option>
                    </select>
                </div>

                {/* ITEMS */}
                <div>
                    <label className="block font-medium mb-2">Items</label>
                    {data.items.map((item, idx) => (
                        <div key={idx} className="flex gap-2 mb-2 p-2 border rounded bg-gray-50">
                            <select 
                                value={item.service_id} 
                                onChange={e => handleItemChange(idx, 'service_id', e.target.value)} 
                                className="border rounded px-2 py-1 flex-1"
                            >
                                <option value="">-- Pilih Service --</option>
                                {services.map(s => (
                                    <option key={s.id} value={s.id}>
                                        {s.name} - Rp {parseFloat(s.price).toLocaleString('id-ID')}/kg
                                    </option>
                                ))}
                            </select>
                            
                            <input 
                                type="number" 
                                step="0.1"
                                min="0" 
                                value={item.quantity} 
                                onChange={e => handleItemChange(idx, 'quantity', e.target.value)} 
                                className="border rounded px-2 py-1 w-20" 
                                placeholder="Qty"
                            />
                            
                            <label className="flex items-center">
                                <input 
                                    type="checkbox" 
                                    checked={item.is_express} 
                                    onChange={e => handleItemChange(idx, 'is_express', e.target.checked)} 
                                    className="mr-1"
                                /> 
                                ⚡ Express
                            </label>
                            
                            <input 
                                type="text" 
                                value={item.notes} 
                                onChange={e => handleItemChange(idx, 'notes', e.target.value)} 
                                placeholder="Catatan..." 
                                className="border rounded px-2 py-1 flex-1" 
                            />
                            
                            {data.items.length > 1 && (
                                <button type="button" onClick={() => removeItem(idx)} className="text-red-500 hover:text-red-700 px-2">
                                    🗑️
                                </button>
                            )}
                        </div>
                    ))}
                    <button type="button" onClick={addItem} className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-sm">
                        ➕ Tambah Item
                    </button>
                </div>

                {/* TOTALS */}
                <div className="bg-blue-50 p-4 rounded">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block font-medium">Subtotal</label>
                            <input 
                                type="text" 
                                value={`Rp ${calculateTotal().toLocaleString('id-ID')}`} 
                                disabled 
                                className="w-full border rounded px-2 py-1 bg-white" 
                            />
                        </div>

                        <div>
                            <label className="block font-medium">Tipe Diskon</label>
                            <select value={data.discount_type} onChange={handleDiscountTypeChange} className="w-full border rounded px-2 py-1">
                                <option value="amount">Nominal (Rp)</option>
                                <option value="percent">Persen (%)</option>
                            </select>
                        </div>

                        <div>
                            <label className="block font-medium">Nilai Diskon</label>
                            <input 
                                type="number" 
                                min="0" 
                                step="0.01"
                                value={data.discount_value} 
                                onChange={handleDiscountValueChange} 
                                className="w-full border rounded px-2 py-1" 
                                placeholder={data.discount_type === 'percent' ? 'Persen' : 'Rupiah'}
                            />
                        </div>

                        <div>
                            <label className="block font-medium font-bold text-lg">TOTAL AKHIR</label>
                            <input 
                                type="text" 
                                value={`Rp ${calculateFinalTotal().toLocaleString('id-ID')}`} 
                                disabled 
                                className="w-full border rounded px-2 py-1 bg-yellow-100 font-bold text-lg" 
                            />
                        </div>
                    </div>
                </div>

                {/* PAYMENT */}
                <div className="bg-green-50 p-4 rounded">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block font-medium">Jumlah Dibayar</label>
                            <input 
                                type="number" 
                                min="0" 
                                step="0.01"
                                value={data.paid_amount} 
                                onChange={e => setData('paid_amount', e.target.value)} 
                                className="w-full border rounded px-2 py-1" 
                            />
                        </div>

                        <div>
                            <label className="block font-medium">Status Pembayaran</label>
                            <select value={data.payment_status} onChange={handlePaymentStatusChange} className="w-full border rounded px-2 py-1">
                                <option value="belum lunas">🔴 Belum Lunas</option>
                                <option value="dp">🟡 DP (Down Payment)</option>
                                <option value="lunas">🟢 Lunas</option>
                            </select>
                        </div>

                        <div className="md:col-span-2">
                            <label className="block font-medium">Sisa Pembayaran</label>
                            <input 
                                type="text" 
                                value={`Rp ${Math.max(0, calculateFinalTotal() - parseFloat(data.paid_amount || 0)).toLocaleString('id-ID')}`} 
                                disabled 
                                className="w-full border rounded px-2 py-1 bg-red-100" 
                            />
                        </div>
                    </div>
                </div>

                {/* NOTES */}
                <div>
                    <label className="block font-medium">Catatan</label>
                    <textarea 
                        value={data.notes} 
                        onChange={e => setData('notes', e.target.value)} 
                        className="w-full border rounded px-2 py-1" 
                        rows="3"
                        placeholder="Catatan tambahan untuk transaksi ini..."
                    />
                </div>

                {/* ACTION BUTTONS */}
                <div className="flex justify-between pt-4 border-t">
                    <Link 
                        href={route('transactions.show', transaction.id)} 
                        className="bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded transition-colors"
                    >
                        ← Kembali
                    </Link>
                    
                    <div className="flex gap-2">
                        <Link 
                            href={route('transactions.index')} 
                            className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded transition-colors"
                        >
                            📋 Daftar Transaksi
                        </Link>
                        
                        <button 
                            type="submit" 
                            disabled={processing} 
                            className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white py-2 px-4 rounded transition-colors"
                        >
                            {processing ? '⏳ Menyimpan...' : '💾 Update Transaksi'}
                        </button>
                    </div>
                </div>
            </form>

            {/* Click outside to close dropdown */}
            {showCustomerDropdown && (
                <div 
                    className="fixed inset-0 z-30" 
                    onClick={() => setShowCustomerDropdown(false)}
                ></div>
            )}
        </AuthenticatedLayout>
    );
}
