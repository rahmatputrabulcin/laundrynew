import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { Head, Link } from "@inertiajs/react";

export default function Show({ transaction, auth }) {
  const formatDate = (dateString) => {
    if (!dateString) return "-";
    const date = new Date(dateString);
    return date.toLocaleDateString("id-ID", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return "-";
    const date = new Date(dateString);
    return date.toLocaleString("id-ID", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatCurrency = (amount) => {
    return `Rp ${parseFloat(amount || 0).toLocaleString("id-ID")}`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "processing":
        return "bg-blue-100 text-blue-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "delivered":
        return "bg-purple-100 text-purple-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getPaymentStatusColor = (status) => {
    switch (status) {
      case "lunas":
        return "bg-green-100 text-green-800";
      case "belum lunas":
        return "bg-red-100 text-red-800";
      case "dp":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const calculateSubtotal = () => {
    return transaction.details?.reduce((sum, detail) => {
      return sum + detail.quantity * detail.price;
    }, 0);
  };

  const calculateExpressFee = () => {
    return transaction.details?.reduce((sum, detail) => {
      return sum + (detail.express_fee || 0);
    }, 0);
  };

  return (
    <AuthenticatedLayout
      user={auth.user}
      header={
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-blue-700">
            📋 Detail Transaksi #{transaction.invoice_number}
          </h2>
          <div className="flex gap-2">
            <Link
              href={route("transactions.edit", transaction.id)}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded text-sm"
            >
              ✏️ Edit
            </Link>
            <a
              href={route("transactions.print", transaction.id)}
              className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded text-sm"
              target="_blank"
              rel="noopener noreferrer"
            >
              🖨️ Print
            </a>
            <Link
              href={route("transactions.index")}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded text-sm"
            >
              ← Kembali
            </Link>
          </div>
        </div>
      }
    >
      <Head title={`Detail Transaksi ${transaction.invoice_number}`} />

      <div className="max-w-6xl mx-auto p-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Transaction Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Transaction Header */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-bold text-gray-800">
                    {transaction.invoice_number}
                  </h3>
                  <p className="text-gray-600">
                    Tanggal:{" "}
                    {formatDate(transaction.transaction_date)}
                  </p>
                </div>
                <div className="text-right">
                  <span
                    className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${getStatusColor(
                      transaction.status
                    )}`}
                  >
                    {transaction.status}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-gray-700 mb-2">
                    👤 Informasi Pelanggan
                  </h4>
                  <div className="bg-gray-50 p-3 rounded">
                    <p className="font-medium">{transaction.customer?.name || "-"}</p>
                    <p className="text-sm text-gray-600">
                      {transaction.customer?.phone || "-"}
                    </p>
                    <p className="text-sm text-gray-600">
                      {transaction.customer?.address || "-"}
                    </p>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-700 mb-2">📅 Timeline</h4>
                  <div className="bg-gray-50 p-3 rounded space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Dibuat:</span>
                      <span>{formatDateTime(transaction.created_at)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Estimasi Selesai:</span>
                      <span
                        className={
                          new Date(transaction.estimated_completion) < new Date() &&
                          transaction.status !== "completed"
                            ? "text-red-600 font-medium"
                            : ""
                        }
                      >
                        {formatDate(transaction.estimated_completion)}
                        {new Date(transaction.estimated_completion) < new Date() &&
                          transaction.status !== "completed" && (
                            <span className="ml-1">⚠️</span>
                          )}
                      </span>
                    </div>
                    {transaction.completed_at && (
                      <div className="flex justify-between text-sm">
                        <span>Diselesaikan:</span>
                        <span className="text-green-600">
                          {formatDateTime(transaction.completed_at)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Service Details */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">🧺 Detail Layanan</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Layanan
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Quantity
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Harga
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Express
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Subtotal
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {transaction.details?.map((detail, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-4 py-3 text-sm">
                          <div>
                            <div className="font-medium">{detail.service?.name}</div>
                            {detail.notes && (
                              <div className="text-xs text-gray-500 mt-1">
                                {detail.notes}
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          {detail.quantity} kg
                        </td>
                        <td className="px-4 py-3 text-sm">
                          {formatCurrency(detail.price)}
                        </td>
                        <td className="px-4 py-3 text-sm">
                          {detail.is_express ? (
                            <div>
                              <span className="text-red-600">⚡ Ya</span>
                              {detail.express_fee > 0 && (
                                <div className="text-xs text-gray-500">
                                  +{formatCurrency(detail.express_fee)}
                                </div>
                              )}
                            </div>
                          ) : (
                            <span className="text-gray-400">Tidak</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-sm font-medium">
                          {formatCurrency(detail.subtotal)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Notes */}
            {transaction.notes && (
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">📝 Catatan</h3>
                <div className="bg-gray-50 p-4 rounded">
                  <p className="text-gray-700">{transaction.notes}</p>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Payment Summary */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">💰 Ringkasan Pembayaran</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>{formatCurrency(calculateSubtotal())}</span>
                </div>

                {calculateExpressFee() > 0 && (
                  <div className="flex justify-between">
                    <span>Biaya Express:</span>
                    <span>{formatCurrency(calculateExpressFee())}</span>
                  </div>
                )}

                {transaction.discount_value > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>
                      Diskon (
                      {transaction.discount_type === "amount"
                        ? "Nominal"
                        : "Persen"}
                      ):
                    </span>
                    <span>
                      -{transaction.discount_type === "amount"
                        ? formatCurrency(transaction.discount_value)
                        : `${transaction.discount_value}%`}
                    </span>
                  </div>
                )}

                <hr className="my-3" />

                <div className="flex justify-between text-lg font-bold">
                  <span>Total:</span>
                  <span>{formatCurrency(transaction.final_total)}</span>
                </div>

                <div className="flex justify-between">
                  <span>Dibayar:</span>
                  <span className="font-medium">
                    {formatCurrency(transaction.paid_amount)}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span>Sisa:</span>
                  <span
                    className={`font-bold ${
                      transaction.final_total - transaction.paid_amount > 0
                        ? "text-red-600"
                        : "text-green-600"
                    }`}
                  >
                    {formatCurrency(transaction.final_total - transaction.paid_amount)}
                  </span>
                </div>
              </div>
            </div>

            {/* Payment Status */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">💳 Status Pembayaran</h3>
              <div className="text-center">
                <span
                  className={`inline-flex px-4 py-2 text-sm font-semibold rounded-full ${getPaymentStatusColor(
                    transaction.payment_status
                  )}`}
                >
                  {transaction.payment_status}
                </span>

                {transaction.payment_status !== "lunas" && (
                  <div className="mt-4">
                    <Link
                      href={route("transactions.edit", transaction.id)}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded text-sm inline-block"
                    >
                      💰 Update Pembayaran
                    </Link>
                  </div>
                )}
              </div>
            </div>

            {/* Status Progress */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">🔄 Progress Status</h3>
              <div className="space-y-3">
                <div
                  className={`flex items-center ${
                    ["pending", "processing", "completed", "delivered", "cancelled"].includes(
                      transaction.status
                    )
                      ? "text-green-600"
                      : "text-gray-400"
                  }`}
                >
                  <div
                    className={`w-3 h-3 rounded-full mr-3 ${
                      transaction.status === "pending"
                        ? "bg-yellow-500"
                        : ["processing", "completed", "delivered"].includes(
                            transaction.status
                          )
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                  <span className="text-sm">Pending</span>
                </div>

                <div
                  className={`flex items-center ${
                    ["processing", "completed", "delivered"].includes(transaction.status)
                      ? "text-green-600"
                      : "text-gray-400"
                  }`}
                >
                  <div
                    className={`w-3 h-3 rounded-full mr-3 ${
                      transaction.status === "processing"
                        ? "bg-blue-500"
                        : ["completed", "delivered"].includes(transaction.status)
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                  <span className="text-sm">Processing</span>
                </div>

                <div
                  className={`flex items-center ${
                    ["completed", "delivered"].includes(transaction.status)
                      ? "text-green-600"
                      : "text-gray-400"
                  }`}
                >
                  <div
                    className={`w-3 h-3 rounded-full mr-3 ${
                      transaction.status === "completed"
                        ? "bg-green-500"
                        : transaction.status === "delivered"
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                  <span className="text-sm">Completed</span>
                </div>

                <div
                  className={`flex items-center ${
                    transaction.status === "delivered"
                      ? "text-green-600"
                      : "text-gray-400"
                  }`}
                >
                  <div
                    className={`w-3 h-3 rounded-full mr-3 ${
                      transaction.status === "delivered"
                        ? "bg-purple-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                  <span className="text-sm">Delivered</span>
                </div>

                {transaction.status === "cancelled" && (
                  <div className="flex items-center text-red-600">
                    <div className="w-3 h-3 rounded-full mr-3 bg-red-500"></div>
                    <span className="text-sm">Cancelled</span>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">⚡ Aksi Cepat</h3>
              <div className="space-y-2">
                <Link
                  href={route("transactions.edit", transaction.id)}
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded text-sm text-center block"
                >
                  ✏️ Edit Transaksi
                </Link>

                <a
                  href={route("transactions.print", transaction.id)}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded text-sm text-center block"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  🖨️ Print Struk
                </a>

                {transaction.status !== "delivered" &&
                  transaction.status !== "cancelled" && (
                    <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded text-sm">
                      🔄 Update Status
                    </button>
                  )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </AuthenticatedLayout>
  );
}
