import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';
import { useState, useEffect } from 'react';

export default function Create({ customers, services, products, auth, invoiceNumber }) {
    const { data, setData, post, processing, errors } = useForm({
        invoice_number: invoiceNumber || '',
        customer_id: '',
        transaction_date: new Date().toISOString().split('T')[0],
        estimated_completion: '',
        notes: '',
        discount_type: 'amount',
        discount_value: 0,
        paid_amount: 0,
        payment_status: 'belum lunas',
        status: 'pending',
        total_amount: 0,
        items: [
            {
                type: 'service', // 'service' or 'product'
                service_id: '', // untuk service
                product_id: '', // untuk product
                quantity: 0,
                price: 0,
                is_express: false,
                express_fee: 0,
                notes: ''
            }
        ]
    });

    const [selectedCustomer, setSelectedCustomer] = useState(null);
    const [subtotal, setSubtotal] = useState(0);
    const [total, setTotal] = useState(0);
    
    // Searchable Select States
    const [customerSearch, setCustomerSearch] = useState('');
    const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
    const [filteredCustomers, setFilteredCustomers] = useState([]);

    // Initialize filtered customers
    useEffect(() => {
        if (customers && Array.isArray(customers)) {
            const mappedCustomers = customers.map(customer => ({
                ...customer,
                phone: customer.phone_number
            }));
            setFilteredCustomers(mappedCustomers);
        }
    }, [customers]);

    // Recalculate total when data changes
    useEffect(() => {
        calculateTotal();
    }, [data.discount_type, data.discount_value, data.items]);

    // Update total_amount in form data
    useEffect(() => {
        setData('total_amount', total);
    }, [total]);

    // Handle customer search
    const handleCustomerSearch = (searchTerm) => {
        setCustomerSearch(searchTerm);
        
        if (!customers || !Array.isArray(customers)) {
            setFilteredCustomers([]);
            setShowCustomerDropdown(false);
            return;
        }

        if (!searchTerm.trim()) {
            const mappedCustomers = customers.map(customer => ({
                ...customer,
                phone: customer.phone_number
            }));
            setFilteredCustomers(mappedCustomers);
            setShowCustomerDropdown(true);
            return;
        }

        try {
            const searchLower = searchTerm.toLowerCase();
            const filtered = customers.filter(customer => {
                if (!customer) return false;
                
                const name = customer.name || '';
                const phone = customer.phone_number || '';
                
                const nameMatch = name.toString().toLowerCase().includes(searchLower);
                const phoneMatch = phone.toString().toLowerCase().includes(searchLower);
                
                return nameMatch || phoneMatch;
            }).map(customer => ({
                ...customer,
                phone: customer.phone_number
            }));
            
            setFilteredCustomers(filtered);
            setShowCustomerDropdown(true);
            
        } catch (error) {
            console.error('Error filtering customers:', error);
            setFilteredCustomers([]);
            setShowCustomerDropdown(false);
        }
    };

    const selectCustomer = (customer) => {
        if (!customer || !customer.id) {
            console.error('Invalid customer data:', customer);
            return;
        }
        
        setData('customer_id', customer.id);
        setSelectedCustomer(customer);
        setCustomerSearch(customer.name || '');
        setShowCustomerDropdown(false);
    };

    const clearCustomerSelection = () => {
        setData('customer_id', '');
        setSelectedCustomer(null);
        setCustomerSearch('');
        setShowCustomerDropdown(false);
        const mappedCustomers = customers?.map(customer => ({
            ...customer,
            phone: customer.phone_number
        })) || [];
        setFilteredCustomers(mappedCustomers);
    };

    const addItem = () => {
        setData('items', [...data.items, {
            type: 'service',
            service_id: '',
            product_id: '',
            quantity: 0,
            price: 0,
            is_express: false,
            express_fee: 0,
            notes: ''
        }]);
    };

    const removeItem = (index) => {
        const newItems = data.items.filter((_, i) => i !== index);
        setData('items', newItems);
    };

    const updateItem = (index, field, value) => {
        const newItems = [...data.items];
        newItems[index][field] = value;

        // Auto-fill price when service/product is selected
        if ((field === 'service_id' || field === 'product_id') && value) {
            const itemType = newItems[index].type;
            let selectedItem;
            
            if (itemType === 'service' && field === 'service_id') {
                selectedItem = services?.find(s => s.id == value);
            } else if (itemType === 'product' && field === 'product_id') {
                selectedItem = products?.find(p => p.id == value);
            }
            
            if (selectedItem) {
                newItems[index].price = parseFloat(selectedItem.price);
            }
        }

        // Reset fields when type changes
        if (field === 'type') {
            newItems[index].service_id = '';
            newItems[index].product_id = '';
            newItems[index].price = 0;
            newItems[index].is_express = false;
            newItems[index].express_fee = 0;
        }

        setData('items', newItems);
    };

    const calculateTotal = () => {
        const newSubtotal = data.items.reduce((sum, item) => {
            const itemTotal = (parseFloat(item.quantity) * parseFloat(item.price)) + (item.is_express ? parseFloat(item.express_fee) : 0);
            return sum + (isNaN(itemTotal) ? 0 : itemTotal);
        }, 0);

        setSubtotal(newSubtotal);

        let discountAmount = 0;
        if (data.discount_type === 'amount') {
            discountAmount = parseFloat(data.discount_value) || 0;
        } else {
            discountAmount = (newSubtotal * (parseFloat(data.discount_value) || 0)) / 100;
        }

        const finalTotal = newSubtotal - discountAmount;
        setTotal(Math.max(0, finalTotal));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        
        if (!data.customer_id) {
            alert('Silakan pilih pelanggan terlebih dahulu');
            return;
        }

        // Validate and prepare items
        const validItems = data.items.filter(item => {
            const hasValidId = (item.type === 'service' && item.service_id) || 
                              (item.type === 'product' && item.product_id);
            return hasValidId && item.quantity > 0 && item.price > 0;
        }).map(item => {
            // Clean up the item based on type
            if (item.type === 'service') {
                const { product_id, ...serviceItem } = item;
                return serviceItem;
            } else {
                const { service_id, is_express, express_fee, ...productItem } = item;
                return productItem;
            }
        });

        if (validItems.length === 0) {
            alert('Silakan tambahkan minimal satu item yang valid');
            return;
        }

        // Prepare data for submission
        const submissionData = {
            ...data,
            items: validItems,
            total_amount: total
        };

        console.log('Submitting data:', submissionData);
        
        post(route('transactions.store'));
    };

    const formatCurrency = (amount) => {
        return `Rp ${parseFloat(amount || 0).toLocaleString('id-ID')}`;
    };

    const getItemOptions = (itemType) => {
        if (itemType === 'service') {
            return services || [];
        } else if (itemType === 'product') {
            return products || [];
        }
        return [];
    };

    const getSelectedItemId = (item) => {
        return item.type === 'service' ? item.service_id : item.product_id;
    };

    const getItemFieldName = (itemType) => {
        return itemType === 'service' ? 'service_id' : 'product_id';
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-blue-700">➕ Tambah Transaksi Baru</h2>
                    <Link 
                        href={route('transactions.index')}
                        className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded text-sm"
                    >
                        ← Kembali
                    </Link>
                </div>
            }
        >
            <Head title="Tambah Transaksi" />

            <div className="max-w-6xl mx-auto p-4">
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        
                        {/* Main Form */}
                        <div className="lg:col-span-2 space-y-6">
                            
                            {/* Customer & Basic Info */}
                            <div className="bg-white rounded-lg shadow p-6">
                                <h3 className="text-lg font-semibold mb-4">👤 Informasi Pelanggan & Transaksi</h3>
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {/* Invoice Number */}
                                    <div>
                                        <label className="block text-sm font-medium mb-1">Invoice Number</label>
                                        <input
                                            type="text"
                                            value={data.invoice_number}
                                            onChange={(e) => setData('invoice_number', e.target.value)}
                                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                            placeholder="INV-XXXXXXXX"
                                            required
                                        />
                                        {errors.invoice_number && <p className="text-red-500 text-xs mt-1">{errors.invoice_number}</p>}
                                    </div>

                                    <div className="relative">
                                        <label className="block text-sm font-medium mb-1">Pelanggan *</label>
                                        <div className="relative">
                                            <input
                                                type="text"
                                                value={customerSearch}
                                                onChange={(e) => handleCustomerSearch(e.target.value)}
                                                onFocus={() => {
                                                    setShowCustomerDropdown(true);
                                                }}
                                                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-10"
                                                placeholder="Ketik nama atau nomor telepon..."
                                                autoComplete="off"
                                            />
                                            
                                            {/* Clear button */}
                                            {customerSearch && (
                                                <button
                                                    type="button"
                                                    onClick={clearCustomerSelection}
                                                    className="absolute right-2 top-2 text-gray-400 hover:text-gray-600 z-10"
                                                >
                                                    ✕
                                                </button>
                                            )}
                                            
                                            {/* Search Icon */}
                                            {!customerSearch && (
                                                <div className="absolute right-2 top-2 text-gray-400 pointer-events-none">
                                                    🔍
                                                </div>
                                            )}
                                        </div>

                                        {/* Dropdown Results */}
                                        {showCustomerDropdown && (
                                            <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto">
                                                {filteredCustomers && filteredCustomers.length > 0 ? (
                                                    filteredCustomers.map((customer, index) => (
                                                        <div
                                                            key={customer.id || index}
                                                            onClick={() => selectCustomer(customer)}
                                                            className="px-4 py-3 hover:bg-blue-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                                                        >
                                                            <div className="font-medium text-gray-900">
                                                                {customer.name || 'Nama tidak tersedia'}
                                                            </div>
                                                            <div className="text-sm text-gray-600">
                                                                📞 {customer.phone || 'Phone tidak tersedia'}
                                                            </div>
                                                            {customer.address && (
                                                                <div className="text-xs text-gray-500 truncate">
                                                                    📍 {customer.address}
                                                                </div>
                                                            )}
                                                        </div>
                                                    ))
                                                ) : (
                                                    <div className="px-4 py-3 text-center text-gray-500">
                                                        {customerSearch ? (
                                                            <>
                                                                <div className="text-sm mb-2">❌ Pelanggan tidak ditemukan</div>
                                                                <Link 
                                                                    href={route('customers.create')}
                                                                    className="text-blue-600 hover:text-blue-800 text-sm underline"
                                                                >
                                                                    ➕ Tambah Pelanggan Baru
                                                                </Link>
                                                            </>
                                                        ) : (
                                                            <div className="text-sm">Tidak ada data pelanggan</div>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        )}

                                        {errors.customer_id && <p className="text-red-500 text-xs mt-1">{errors.customer_id}</p>}
                                        
                                        {/* Selected Customer Preview */}
                                        {selectedCustomer && (
                                            <div className="mt-2 p-3 bg-blue-50 rounded-lg text-sm border border-blue-200">
                                                <div className="flex justify-between items-start">
                                                    <div className="flex-1">
                                                        <p><strong>👤 Nama:</strong> {selectedCustomer.name || '-'}</p>
                                                        <p><strong>📞 Phone:</strong> {selectedCustomer.phone || selectedCustomer.phone_number || '-'}</p>
                                                        <p><strong>📍 Alamat:</strong> {selectedCustomer.address || '-'}</p>
                                                    </div>
                                                    <button
                                                        type="button"
                                                        onClick={clearCustomerSelection}
                                                        className="text-red-500 hover:text-red-700 text-xs ml-2 bg-white px-2 py-1 rounded border"
                                                    >
                                                        ✕ Batal
                                                    </button>
                                                </div>
                                            </div>
                                        )}
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium mb-1">Tanggal Transaksi *</label>
                                        <input
                                            type="date"
                                            value={data.transaction_date}
                                            onChange={(e) => setData('transaction_date', e.target.value)}
                                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                            required
                                        />
                                        {errors.transaction_date && <p className="text-red-500 text-xs mt-1">{errors.transaction_date}</p>}
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium mb-1">Estimasi Selesai *</label>
                                        <input
                                            type="date"
                                            value={data.estimated_completion}
                                            onChange={(e) => setData('estimated_completion', e.target.value)}
                                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                            required
                                        />
                                        {errors.estimated_completion && <p className="text-red-500 text-xs mt-1">{errors.estimated_completion}</p>}
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium mb-1">Status</label>
                                        <select
                                            value={data.status}
                                            onChange={(e) => setData('status', e.target.value)}
                                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                        >
                                            <option value="pending">Pending</option>
                                            <option value="processing">Processing</option>
                                            <option value="completed">Completed</option>
                                            <option value="delivered">Delivered</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="mt-4">
                                    <label className="block text-sm font-medium mb-1">Catatan</label>
                                    <textarea
                                        value={data.notes}
                                        onChange={(e) => setData('notes', e.target.value)}
                                        className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                        rows="3"
                                        placeholder="Catatan tambahan..."
                                    ></textarea>
                                </div>
                            </div>

                            {/* Items Details */}
                            <div className="bg-white rounded-lg shadow p-6">
                                <div className="flex justify-between items-center mb-4">
                                    <h3 className="text-lg font-semibold">🧺 Detail Items</h3>
                                    <button
                                        type="button"
                                        onClick={addItem}
                                        className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm transition-colors"
                                    >
                                        ➕ Tambah Item
                                    </button>
                                </div>

                                <div className="space-y-4">
                                    {data.items.map((item, index) => (
                                        <div key={index} className="border rounded-lg p-4 bg-gray-50">
                                            <div className="flex justify-between items-center mb-3">
                                                <h4 className="font-medium">Item #{index + 1}</h4>
                                                {data.items.length > 1 && (
                                                    <button
                                                        type="button"
                                                        onClick={() => removeItem(index)}
                                                        className="text-red-600 hover:text-red-800 text-sm hover:bg-red-50 px-2 py-1 rounded transition-colors"
                                                    >
                                                        🗑️ Hapus
                                                    </button>
                                                )}
                                            </div>

                                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                                                <div>
                                                    <label className="block text-sm font-medium mb-1">Tipe *</label>
                                                    <select
                                                        value={item.type}
                                                        onChange={(e) => updateItem(index, 'type', e.target.value)}
                                                        className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                                        required
                                                    >
                                                        <option value="service">Service</option>
                                                        <option value="product">Product</option>
                                                    </select>
                                                </div>

                                                <div>
                                                    <label className="block text-sm font-medium mb-1">
                                                        {item.type === 'service' ? 'Service' : 'Product'} *
                                                    </label>
                                                    <select
                                                        value={getSelectedItemId(item)}
                                                        onChange={(e) => updateItem(index, getItemFieldName(item.type), e.target.value)}
                                                        className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                                        required
                                                    >
                                                        <option value="">Pilih {item.type === 'service' ? 'Service' : 'Product'}</option>
                                                        {getItemOptions(item.type).map(option => (
                                                            <option key={option.id} value={option.id}>
                                                                {option.name} - {formatCurrency(option.price)}
                                                                {item.type === 'service' ? '/kg' : ''}
                                                            </option>
                                                        ))}
                                                    </select>
                                                    {/* Show specific error for this field */}
                                                    {errors[`items.${index}.service_id`] && (
                                                        <p className="text-red-500 text-xs mt-1">{errors[`items.${index}.service_id`]}</p>
                                                    )}
                                                    {errors[`items.${index}.product_id`] && (
                                                        <p className="text-red-500 text-xs mt-1">{errors[`items.${index}.product_id`]}</p>
                                                    )}
                                                </div>

                                                <div>
                                                    <label className="block text-sm font-medium mb-1">
                                                        Quantity {item.type === 'service' ? '(kg)' : '(pcs)'} *
                                                    </label>
                                                    <input
                                                        type="number"
                                                        step={item.type === 'service' ? '0.1' : '1'}
                                                        min="0"
                                                        value={item.quantity}
                                                        onChange={(e) => updateItem(index, 'quantity', parseFloat(e.target.value) || 0)}
                                                        className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                                        required
                                                    />
                                                </div>

                                                <div>
                                                    <label className="block text-sm font-medium mb-1">
                                                        Harga/{item.type === 'service' ? 'kg' : 'pcs'}
                                                    </label>
                                                    <input
                                                        type="number"
                                                        min="0"
                                                        value={item.price}
                                                        onChange={(e) => updateItem(index, 'price', parseFloat(e.target.value) || 0)}
                                                        className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                                    />
                                                </div>

                                                {item.type === 'service' && (
                                                    <div className="md:col-span-2">
                                                        <div className="flex items-center space-x-4">
                                                            <label className="flex items-center">
                                                                <input
                                                                    type="checkbox"
                                                                    checked={item.is_express}
                                                                    onChange={(e) => updateItem(index, 'is_express', e.target.checked)}
                                                                    className="mr-2 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                                                />
                                                                <span className="text-sm">⚡ Express Service</span>
                                                            </label>
                                                            
                                                            {item.is_express && (
                                                                <div>
                                                                    <input
                                                                        type="number"
                                                                        min="0"
                                                                        value={item.express_fee}
                                                                        onChange={(e) => updateItem(index, 'express_fee', parseFloat(e.target.value) || 0)}
                                                                        className="border border-gray-300 rounded px-2 py-1 text-sm w-24 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                                                        placeholder="Biaya"
                                                                    />
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                )}

                                                <div className="md:col-span-4">
                                                    <label className="block text-sm font-medium mb-1">Catatan Item</label>
                                                    <input
                                                        type="text"
                                                        value={item.notes}
                                                        onChange={(e) => updateItem(index, 'notes', e.target.value)}
                                                        className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                                        placeholder="Catatan khusus untuk item ini..."
                                                    />
                                                </div>
                                            </div>

                                            <div className="mt-3 p-2 bg-white rounded border border-gray-200">
                                                <div className="flex justify-between text-sm">
                                                    <span>Subtotal:</span>
                                                    <span className="font-medium">
                                                        {formatCurrency((item.quantity * item.price) + (item.is_express ? item.express_fee : 0))}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>

                                {errors.items && <p className="text-red-500 text-xs mt-2">{errors.items}</p>}
                            </div>
                        </div>

                        {/* Sidebar - Summary */}
                        <div className="space-y-6">
                            
                            {/* Payment Summary */}
                            <div className="bg-white rounded-lg shadow p-6 sticky top-4">
                                <h3 className="text-lg font-semibold mb-4">💰 Ringkasan Pembayaran</h3>
                                
                                <div className="space-y-3">
                                    <div className="flex justify-between">
                                        <span>Subtotal:</span>
                                        <span className="font-medium">{formatCurrency(subtotal)}</span>
                                    </div>

                                    {/* Discount */}
                                    <div className="border-t pt-3">
                                        <label className="block text-sm font-medium mb-2">Diskon</label>
                                        <div className="flex gap-2 mb-2">
                                            <select
                                                value={data.discount_type}
                                                onChange={(e) => setData('discount_type', e.target.value)}
                                                className="border border-gray-300 rounded px-2 py-1 text-sm focus:ring-2 focus:ring-blue-500"
                                            >
                                                <option value="amount">Nominal</option>
                                                <option value="percent">Persen</option>
                                            </select>
                                            <input
                                                type="number"
                                                min="0"
                                                value={data.discount_value}
                                                onChange={(e) => setData('discount_value', parseFloat(e.target.value) || 0)}
                                                className="flex-1 border border-gray-300 rounded px-2 py-1 text-sm focus:ring-2 focus:ring-blue-500"
                                                placeholder={data.discount_type === 'percent' ? 'Persen' : 'Nominal'}
                                            />
                                        </div>
                                        {data.discount_value > 0 && (
                                            <div className="text-sm text-green-600">
                                                Diskon: -{data.discount_type === 'amount' 
                                                    ? formatCurrency(data.discount_value)
                                                    : `${data.discount_value}% (${formatCurrency((subtotal * data.discount_value) / 100)})`
                                                }
                                            </div>
                                        )}
                                    </div>

                                    <hr />
                                    
                                    <div className="flex justify-between text-lg font-bold text-blue-600">
                                        <span>Total:</span>
                                        <span>{formatCurrency(total)}</span>
                                    </div>
                                    
                                    {errors.total_amount && <p className="text-red-500 text-xs mt-1">{errors.total_amount}</p>}
                                </div>
                            </div>

                            {/* Payment Info */}
                            <div className="bg-white rounded-lg shadow p-6">
                                <h3 className="text-lg font-semibold mb-4">💳 Informasi Pembayaran</h3>
                                
                                <div className="space-y-3">
                                    <div>
                                        <label className="block text-sm font-medium mb-1">Jumlah Dibayar</label>
                                        <input
                                            type="number"
                                            min="0"
                                            value={data.paid_amount}
                                            onChange={(e) => setData('paid_amount', parseFloat(e.target.value) || 0)}
                                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                            placeholder="0"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium mb-1">Status Pembayaran</label>
                                        <select
                                            value={data.payment_status}
                                            onChange={(e) => setData('payment_status', e.target.value)}
                                            className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                        >
                                            <option value="belum lunas">Belum Lunas</option>
                                            <option value="dp">DP</option>
                                            <option value="lunas">Lunas</option>
                                        </select>
                                    </div>

                                    <div className="bg-gray-50 p-3 rounded border">
                                        <div className="flex justify-between text-sm">
                                            <span>Sisa:</span>
                                            <span className={`font-medium ${(total - data.paid_amount) > 0 ? 'text-red-600' : 'text-green-600'}`}>
                                                {formatCurrency(total - data.paid_amount)}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Submit */}
                            <div className="bg-white rounded-lg shadow p-6">
                                <button
                                    type="submit"
                                    disabled={processing || !data.customer_id}
                                    className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white py-3 px-4 rounded font-medium transition-colors"
                                >
                                    {processing ? '⏳ Menyimpan...' : '💾 Simpan Transaksi'}
                                </button>
                                
                                {!data.customer_id && (
                                    <p className="text-red-500 text-xs mt-2 text-center">
                                        Pilih pelanggan terlebih dahulu
                                    </p>
                                )}
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            {/* Click outside to close dropdown */}
            {showCustomerDropdown && (
                <div 
                    className="fixed inset-0 z-30" 
                    onClick={() => setShowCustomerDropdown(false)}
                ></div>
            )}
        </AuthenticatedLayout>
    );
}
