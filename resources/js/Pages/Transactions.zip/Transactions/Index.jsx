import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { Head, Link, useForm } from "@inertiajs/react";

export default function Index({ transactions, auth, filters }) {
  const { data, setData, get } = useForm({
    status: filters.status || "",
    customer_name: filters.customer_name || "",
    date_start: filters.date_start || "",
    date_end: filters.date_end || "",
    payment_status: filters.payment_status || "",
  });

  const handleFilter = (e) => {
    e.preventDefault();
    get(route("transactions.index"), { preserveState: true });
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit', 
      year: 'numeric'
    });
  };

  const formatCurrency = (amount) => {
    return `Rp ${parseFloat(amount || 0).toLocaleString('id-ID')}`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'delivered': return 'bg-purple-100 text-purple-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPaymentStatusColor = (status) => {
    switch (status) {
      case 'lunas': return 'text-green-600 font-medium';
      case 'belum lunas': return 'text-red-600 font-medium';
      case 'dp': return 'text-yellow-600 font-medium';
      default: return 'text-gray-600';
    }
  };

  return (
    <AuthenticatedLayout
      user={auth.user}
      header={
        <h2 className="font-semibold text-xl text-gray-800 leading-tight">
          📋 Daftar Transaksi
        </h2>
      }
    >
      <Head title="Transactions" />
      <div className="py-12">
        <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
          
          {/* Header Actions */}
          <div className="flex justify-between items-center mb-6">
            <div className="flex gap-2">
              <a
                href={route("transactions.export", data)}
                className="bg-green-500 hover:bg-green-700 text-white px-4 py-2 rounded text-sm"
                target="_blank"
                rel="noopener noreferrer"
              >
                📊 Export Excel
              </a>
              <a
                href={route("transactions.exportPdf", data)}
                className="bg-red-500 hover:bg-red-700 text-white px-4 py-2 rounded text-sm"
                target="_blank"
                rel="noopener noreferrer"
              >
                📄 Export PDF
              </a>
            </div>
            <Link
              href={route("transactions.create")}
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            >
              ➕ Tambah Transaksi
            </Link>
          </div>

          <div className="bg-white shadow-sm sm:rounded-lg">
            
            {/* Filter Section */}
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-medium mb-4">🔍 Filter Transaksi</h3>
              <form onSubmit={handleFilter} className="grid grid-cols-2 md:grid-cols-6 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Status Transaksi</label>
                  <select
                    value={data.status}
                    onChange={(e) => setData("status", e.target.value)}
                    className="w-full border rounded px-3 py-2 text-sm"
                  >
                    <option value="">Semua Status</option>
                    <option value="pending">Pending</option>
                    <option value="processing">Processing</option>
                    <option value="completed">Completed</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Status Pembayaran</label>
                  <select
                    value={data.payment_status}
                    onChange={(e) => setData("payment_status", e.target.value)}
                    className="w-full border rounded px-3 py-2 text-sm"
                  >
                    <option value="">Semua</option>
                    <option value="lunas">Lunas</option>
                    <option value="belum lunas">Belum Lunas</option>
                    <option value="dp">DP</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Nama Pelanggan</label>
                  <input
                    type="text"
                    placeholder="Cari nama..."
                    value={data.customer_name}
                    onChange={(e) => setData("customer_name", e.target.value)}
                    className="w-full border rounded px-3 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Dari Tanggal</label>
                  <input
                    type="date"
                    value={data.date_start}
                    onChange={e => setData("date_start", e.target.value)}
                    className="w-full border rounded px-3 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Sampai Tanggal</label>
                  <input
                    type="date"
                    value={data.date_end}
                    onChange={e => setData("date_end", e.target.value)}
                    className="w-full border rounded px-3 py-2 text-sm"
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm font-medium"
                  >
                    🔍 Filter
                  </button>
                </div>
              </form>
            </div>

            {/* Table Section */}
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Invoice
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Pelanggan
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Tanggal Transaksi
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Estimasi Selesai
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Layanan
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Total
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Dibayar
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Pembayaran
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Aksi
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {transactions && transactions.data && transactions.data.length > 0 ? (
                    transactions.data.map((trx) => (
                      <tr key={trx.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3 text-sm font-medium text-blue-600">
                          {trx.invoice_number}
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <div>
                            <div className="font-medium">{trx.customer?.name || '-'}</div>
                            <div className="text-gray-500 text-xs">{trx.customer?.phone || '-'}</div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          {formatDate(trx.transaction_date)}
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <div>
                            <div>{formatDate(trx.estimated_completion)}</div>
                            {new Date(trx.estimated_completion) < new Date() && trx.status !== 'completed' && (
                              <span className="text-red-500 text-xs">⚠️ Terlambat</span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <div className="space-y-1">
                            {trx.details?.slice(0, 2).map((detail, idx) => (
                              <div key={idx} className="text-xs">
                                <span className="font-medium">{detail.service?.name}</span>
                                <span className="text-gray-500"> ({detail.quantity}kg)</span>
                                {detail.is_express && (
                                  <span className="text-red-600 ml-1">⚡</span>
                                )}
                              </div>
                            ))}
                            {trx.details?.length > 2 && (
                              <div className="text-xs text-gray-500">
                                +{trx.details.length - 2} lainnya
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <div>
                            <div className="font-bold">{formatCurrency(trx.final_total)}</div>
                            {trx.discount_value > 0 && (
                              <div className="text-xs text-gray-500">
                                Diskon: {trx.discount_type === "amount" 
                                  ? formatCurrency(trx.discount_value)
                                  : `${trx.discount_value}%`
                                }
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <div>
                            <div className="font-medium">{formatCurrency(trx.paid_amount)}</div>
                            {trx.paid_amount < trx.final_total && (
                              <div className="text-xs text-red-500">
                                Sisa: {formatCurrency(trx.final_total - trx.paid_amount)}
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(trx.status)}`}>
                            {trx.status}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className={getPaymentStatusColor(trx.payment_status)}>
                            {trx.payment_status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <div className="flex gap-2">
                            <Link
                              href={route("transactions.show", trx.id)}
                              className="text-blue-600 hover:text-blue-800 text-xs bg-blue-100 px-2 py-1 rounded"
                            >
                              👁️ Detail
                            </Link>
                            <Link
                              href={route("transactions.edit", trx.id)}
                              className="text-green-600 hover:text-green-800 text-xs bg-green-100 px-2 py-1 rounded"
                            >
                              ✏️ Edit
                            </Link>
                            <a
                              href={route("transactions.print", trx.id)}
                              className="text-purple-600 hover:text-purple-800 text-xs bg-purple-100 px-2 py-1 rounded"
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              🖨️ Print
                            </a>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="10" className="px-4 py-8 text-center text-gray-500">
                        <div className="flex flex-col items-center">
                          <div className="text-6xl mb-4">📭</div>
                          <p className="text-lg font-medium">Tidak ada transaksi</p>
                          <p className="text-sm">Coba ubah filter atau buat transaksi baru</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {transactions.links && (
              <div className="bg-white px-4 py-3 border-t border-gray-200 sm:px-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1 flex justify-between sm:hidden">
                    {transactions.prev_page_url && (
                      <Link 
                        href={transactions.prev_page_url} 
                        className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                      >
                        Previous
                      </Link>
                    )}
                    {transactions.next_page_url && (
                      <Link 
                        href={transactions.next_page_url} 
                        className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                      >
                        Next
                      </Link>
                    )}
                  </div>
                  <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                    <div>
                      <p className="text-sm text-gray-700">
                        Showing <span className="font-medium">{transactions.from}</span> to{' '}
                        <span className="font-medium">{transactions.to}</span> of{' '}
                        <span className="font-medium">{transactions.total}</span> results
                      </p>
                    </div>
                    <div>
                      <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                        {transactions.links.map((link, index) => (
                          <Link
                            key={index}
                            href={link.url || '#'}
                            className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                              link.active
                                ? 'z-10 bg-blue-50 border-blue-500 text-blue-600'
                                : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                            } ${!link.url ? 'cursor-not-allowed opacity-50' : ''}`}
                            dangerouslySetInnerHTML={{ __html: link.label }}
                          />
                        ))}
                      </nav>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </AuthenticatedLayout>
  );
}
